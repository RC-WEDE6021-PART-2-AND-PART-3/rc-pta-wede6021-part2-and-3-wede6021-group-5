<?php
session_start();
require_once 'includes/DBConn.php';
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }
$orders = $conn->query("SELECT o.*, p.title, p.image_path FROM tblOrder o JOIN tblClothes p ON o.product_id = p.id WHERE o.buyer_id = {$_SESSION['user_id']} ORDER BY o.order_date DESC");
?>
<!DOCTYPE html>
<html><head><title>My Orders - Pastimes</title></head>
<body>
<h2>My Orders</h2>
<?php if ($orders->num_rows == 0): echo "<p>No orders yet.</p>"; else: ?>
<table border="1" cellpadding="8">
<tr><th>Order ID</th><th>Product</th><th>Qty</th><th>Total</th><th>Status</th><th>Date</th></tr>
<?php while($ord = $orders->fetch_assoc()): ?>
<tr>
    <td><?php echo $ord['id']; ?></td>
    <td><?php echo htmlspecialchars($ord['title']); ?></td>
    <td><?php echo $ord['quantity']; ?></td>
    <td>R<?php echo number_format($ord['total_amount'],2); ?></td>
    <td><?php echo $ord['order_status']; ?></td>
    <td><?php echo $ord['order_date']; ?></td>
</tr>
<?php endwhile; ?>
</table>
<?php endif; ?>
<a href="index.php">Home</a>
</body>
</html>