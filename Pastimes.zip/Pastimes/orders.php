<?php
require_once 'includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT o.id AS order_id, o.order_date, o.total_amount, o.order_status,
                               p.title, p.image_path, p.brand, o.quantity, p.seller_id
                        FROM tblOrder o
                        JOIN tblClothes p ON o.product_id = p.id
                        WHERE o.buyer_id = ?
                        ORDER BY o.order_date DESC");
$stmt->bind_param('i', $userId);
$stmt->execute();
$orders = $stmt->get_result();

$totalAll = 0;
?>

<h2>My Purchase History</h2>

<?php if ($orders->num_rows == 0): ?>
    <p>You have not placed any orders yet.</p>
<?php else: ?>
    <div style="overflow-x: auto;">
        <table>
            <thead>
                <tr>
                    <th>Order #</th>
                    <th>Date</th>
                    <th>Product</th>
                    <th>Brand</th>
                    <th>Qty</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($order = $orders->fetch_assoc()):
                    $totalAll += $order['total_amount'];
                ?>
                    <tr>
                        <td><?php echo $order['order_id']; ?></td>
                        <td><?php echo date('d M Y H:i', strtotime($order['order_date'])); ?></td>
                        <td>
                            <img src="<?php echo $order['image_path'] ?: 'placeholder.jpg'; ?>" width="40" style="vertical-align: middle;">
                            <?php echo htmlspecialchars($order['title']); ?>
                        </td>
                        <td><?php echo htmlspecialchars($order['brand']); ?></td>
                        <td><?php echo $order['quantity']; ?></td>
                        <td>R <?php echo number_format($order['total_amount'], 2); ?></td>
                        <td><?php echo ucfirst($order['order_status']); ?></td>
                        <td>
                            <?php if ($order['order_status'] == 'delivered'):
                                $check = $conn->query("SELECT id FROM tblReviews WHERE order_id = {$order['order_id']}");
                                if ($check->num_rows == 0): ?>
                                    <a href="rate_seller.php?order_id=<?php echo $order['order_id']; ?>&seller_id=<?php echo $order['seller_id']; ?>" class="btn btn-secondary">Rate Seller</a>
                                <?php else: ?>
                                    Rated
                                <?php endif;
                            endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <p class="total">Total of all purchases: <strong>R <?php echo number_format($totalAll, 2); ?></strong></p>
<?php endif; ?>

<p class="mt-20">
    <a href="index.php">← Back to Shop</a>
</p>

<?php require_once 'includes/footer.php'; ?>