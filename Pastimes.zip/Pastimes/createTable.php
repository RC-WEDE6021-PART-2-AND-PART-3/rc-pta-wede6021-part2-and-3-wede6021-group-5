<?php
require_once 'includes/DBConn.php';

// Drop table if exists
$conn->query("DROP TABLE IF EXISTS tblUser");

// Create table
$createSQL = "CREATE TABLE tblUser (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin','seller','buyer','pending') DEFAULT 'pending',
    verified TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($createSQL)) {
    echo "Table tblUser created.<br>";
} else {
    die("Error creating table: " . $conn->error);
}

// Read userData.txt and insert
$file = fopen('data/userData.txt', 'r');
if (!$file) die("Cannot open userData.txt");

while (($line = fgetcsv($file)) !== false) {
    if (count($line) < 4) continue;
    $full_name = $conn->real_escape_string(trim($line[0]));
    $email = $conn->real_escape_string(trim($line[1]));
    $username = $conn->real_escape_string(trim($line[2]));
    $pass_hash = $conn->real_escape_string(trim($line[3]));

    $sql = "INSERT INTO tblUser (full_name, email, username, password_hash, role, verified)
            VALUES ('$full_name', '$email', '$username', '$pass_hash', 'pending', 0)";
    $conn->query($sql);
}
fclose($file);
echo "Data loaded successfully.";
?>