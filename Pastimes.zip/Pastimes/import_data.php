<?php
require_once 'includes/DBConn.php';

// Delete existing data (keep first 5 users from original userData.txt? or replace all)
// We'll clear all except the admin maybe? For full 30 entries, drop and recreate later.
// For now, just append these 30 entries to the tables.

// Load users (skip header if any)
$file = fopen('data/userData30.txt', 'r');
while (($line = fgetcsv($file, 0, ',')) !== false) {
    if (count($line) < 6) continue;
    $name = $conn->real_escape_string($line[0]);
    $email = $conn->real_escape_string($line[1]);
    $user = $conn->real_escape_string($line[2]);
    $pass = $conn->real_escape_string($line[3]);
    $role = $conn->real_escape_string($line[4]);
    $ver = intval($line[5]);
    $conn->query("INSERT INTO tblUser (full_name, email, username, password_hash, role, verified) VALUES ('$name','$email','$user','$pass','$role',$ver)");
}
fclose($file);

// Load clothes
$file = fopen('data/clothesData.txt', 'r');
while (($line = fgetcsv($file, 0, ',')) !== false) {
    if (count($line) < 10) continue;
    $seller_id = intval($line[0]);
    $title = $conn->real_escape_string($line[1]);
    $desc = $conn->real_escape_string($line[2]);
    $price = floatval($line[3]);
    $cond = $conn->real_escape_string($line[4]);
    $brand = $conn->real_escape_string($line[5]);
    $cat = $conn->real_escape_string($line[6]);
    $size = $conn->real_escape_string($line[7]);
    $img = $conn->real_escape_string($line[8]);
    $status = $conn->real_escape_string($line[9]);
    $conn->query("INSERT INTO tblClothes (seller_id, title, description, price, condition_status, brand, category, size, image_path, status) VALUES ($seller_id,'$title','$desc',$price,'$cond','$brand','$cat','$size','$img','$status')");
}
fclose($file);

// Load orders
$file = fopen('data/ordersData.txt', 'r');
while (($line = fgetcsv($file, 0, ',')) !== false) {
    if (count($line) < 8) continue;
    $buyer_id = intval($line[0]);
    $clothes_id = intval($line[1]);
    $qty = intval($line[2]);
    $total = floatval($line[3]);
    $status = $conn->real_escape_string($line[4]);
    $addr = $conn->real_escape_string($line[5]);
    $city = $conn->real_escape_string($line[6]);
    $code = $conn->real_escape_string($line[7]);
    $conn->query("INSERT INTO tblOrder (buyer_id, product_id, quantity, total_amount, order_status, delivery_address, city, postal_code) VALUES ($buyer_id,$clothes_id,$qty,$total,'$status','$addr','$city','$code')");
}
fclose($file);
echo "Data imported.";
?>