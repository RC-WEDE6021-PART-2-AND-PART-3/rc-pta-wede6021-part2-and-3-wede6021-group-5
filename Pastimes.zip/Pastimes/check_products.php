<?php
require_once 'includes/DBConn.php';
$result = $conn->query("SELECT id, title, status FROM tblClothes");
echo "<h3>All Products in tblClothes</h3>";
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "ID: {$row['id']}, Title: {$row['title']}, Status: {$row['status']}<br>";
    }
} else {
    echo "No products found in tblClothes.";
}
?>