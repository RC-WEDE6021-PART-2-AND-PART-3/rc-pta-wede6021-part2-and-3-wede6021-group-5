<?php
require_once 'includes/DBConn.php';

// Add stock_quantity column if not exists
$conn->query("ALTER TABLE tblClothes ADD COLUMN IF NOT EXISTS stock_quantity INT DEFAULT 1 AFTER price");

// Create messages table
$conn->query("CREATE TABLE IF NOT EXISTS tblMessages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sender_id INT NOT NULL,
    receiver_id INT NOT NULL,
    subject VARCHAR(255) DEFAULT 'No Subject',
    message TEXT NOT NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id) REFERENCES tblUser(id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_id) REFERENCES tblUser(id) ON DELETE CASCADE
)");

// Create reviews table
$conn->query("CREATE TABLE IF NOT EXISTS tblReviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    buyer_id INT NOT NULL,
    seller_id INT NOT NULL,
    rating TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES tblOrder(id) ON DELETE CASCADE,
    FOREIGN KEY (buyer_id) REFERENCES tblUser(id) ON DELETE CASCADE,
    FOREIGN KEY (seller_id) REFERENCES tblUser(id) ON DELETE CASCADE
)");

echo "Database updated – stock_quantity column, tblMessages, tblReviews created.";
?>