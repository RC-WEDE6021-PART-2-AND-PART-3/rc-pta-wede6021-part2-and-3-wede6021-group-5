<?php
require_once 'includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$error = '';
$success = '';

$users = $conn->query("SELECT id, full_name, username, role FROM tblUser WHERE id != {$_SESSION['user_id']}");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $receiver_id = intval($_POST['receiver_id']);
    $subject = $conn->real_escape_string($_POST['subject']);
    $message = $conn->real_escape_string($_POST['message']);

    if (empty($receiver_id) || empty($message)) {
        $error = "Please select a recipient and write a message.";
    } else {
        $stmt = $conn->prepare("INSERT INTO tblMessages (sender_id, receiver_id, subject, message) VALUES (?, ?, ?, ?)");
        $stmt->bind_param('iiss', $_SESSION['user_id'], $receiver_id, $subject, $message);
        if ($stmt->execute()) {
            $success = "Message sent.";
        } else {
            $error = "Error sending message.";
        }
    }
}
?>

<h2>Compose Message</h2>

<?php if ($error): ?><div class="alert alert-error"><?php echo $error; ?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>

<form method="POST">
    <div class="form-group">
        <label>To</label>
        <select name="receiver_id" required>
            <option value="">Select recipient</option>
            <?php while($u = $users->fetch_assoc()): ?>
                <option value="<?php echo $u['id']; ?>"><?php echo htmlspecialchars($u['full_name'] . " (@{$u['username']}) - {$u['role']}"); ?></option>
            <?php endwhile; ?>
        </select>
    </div>
    <div class="form-group">
        <label>Subject</label>
        <input type="text" name="subject" maxlength="255">
    </div>
    <div class="form-group">
        <label>Message</label>
        <textarea name="message" rows="6" required></textarea>
    </div>
    <button type="submit" class="btn">Send</button>
</form>

<p class="mt-20"><a href="messages.php">← Back to Messages</a></p>

<?php require_once 'includes/footer.php'; ?>