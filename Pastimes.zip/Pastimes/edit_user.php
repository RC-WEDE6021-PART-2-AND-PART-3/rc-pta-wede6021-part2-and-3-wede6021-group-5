<?php
require_once 'includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

$userId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$stmt = $conn->prepare("SELECT * FROM tblUser WHERE id = ?");
$stmt->bind_param('i', $userId);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
if (!$user) {
    echo "<p>User not found.</p>";
    require_once 'includes/footer.php';
    exit;
}

$msg = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $conn->real_escape_string($_POST['full_name']);
    $email = $conn->real_escape_string($_POST['email']);
    $username = $conn->real_escape_string($_POST['username']);
    $role = $_POST['role'];
    $verified = isset($_POST['verified']) ? 1 : 0;

    $update = "UPDATE tblUser SET full_name='$name', email='$email', username='$username', role='$role', verified=$verified";
    if (!empty($_POST['password'])) {
        $hash = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $update .= ", password_hash='$hash'";
    }
    $update .= " WHERE id=$userId";

    if ($conn->query($update)) {
        $msg = '<div class="alert alert-success">User updated successfully.</div>';
        // Refresh user data
        $stmt = $conn->prepare("SELECT * FROM tblUser WHERE id = ?");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
    } else {
        $msg = '<div class="alert alert-error">Error updating: ' . $conn->error . '</div>';
    }
}
?>

<h2>Edit User</h2>
<p><a href="admin_dashboard.php">← Back to Dashboard</a></p>
<?php echo $msg; ?>

<form method="POST">
    <div class="form-group">
        <label>Full Name</label>
        <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
    </div>
    <div class="form-group">
        <label>Email</label>
        <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
    </div>
    <div class="form-group">
        <label>Username</label>
        <input type="text" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
    </div>
    <div class="form-group">
        <label>New Password (leave blank to keep current)</label>
        <input type="password" name="password">
    </div>
    <div class="form-group">
        <label>Role</label>
        <select name="role">
            <option value="buyer" <?php echo $user['role']=='buyer'?'selected':''; ?>>Buyer</option>
            <option value="seller" <?php echo $user['role']=='seller'?'selected':''; ?>>Seller</option>
        </select>
    </div>
    <div class="form-group">
        <label>
            <input type="checkbox" name="verified" value="1" <?php echo $user['verified']?'checked':''; ?>>
            Verified
        </label>
    </div>
    <button type="submit" class="btn">Update User</button>
</form>

<?php require_once 'includes/footer.php'; ?>