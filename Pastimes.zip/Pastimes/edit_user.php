<?php
session_start();
require_once 'includes/DBConn.php';
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

$userId = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($userId == 0) {
    header('Location: admin_dashboard.php');
    exit;
}

// Fetch user
$stmt = $conn->prepare("SELECT * FROM tblUser WHERE id = ?");
$stmt->bind_param('i', $userId);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
if (!$user) {
    echo "User not found.";
    exit;
}

$msg = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $conn->real_escape_string($_POST['full_name']);
    $email = $conn->real_escape_string($_POST['email']);
    $username = $conn->real_escape_string($_POST['username']);
    $role = $_POST['role'];
    $verified = isset($_POST['verified']) ? 1 : 0;
    
    $update = "UPDATE tblUser SET full_name='$name', email='$email', username='$username', role='$role', verified=$verified";
    if (!empty($_POST['password'])) {
        $hash = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $update .= ", password_hash='$hash'";
    }
    $update .= " WHERE id=$userId";
    if ($conn->query($update)) {
        $msg = "User updated successfully.";
        // refresh user data
        $stmt = $conn->prepare("SELECT * FROM tblUser WHERE id = ?");
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
    } else {
        $msg = "Error updating: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit User - Pastimes</title>
</head>
<body>
    <h2>Edit User</h2>
    <p><a href="admin_dashboard.php">← Back to Dashboard</a></p>
    <?php if ($msg) echo "<p>$msg</p>"; ?>
    <form method="POST">
        <label>Full Name:</label><br>
        <input type="text" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" required><br><br>
        <label>Email:</label><br>
        <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required><br><br>
        <label>Username:</label><br>
        <input type="text" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required><br><br>
        <label>New Password (leave blank to keep current):</label><br>
        <input type="password" name="password"><br><br>
        <label>Role:</label>
        <select name="role">
            <option value="buyer" <?php echo $user['role']=='buyer'?'selected':''; ?>>Buyer</option>
            <option value="seller" <?php echo $user['role']=='seller'?'selected':''; ?>>Seller</option>
        </select><br><br>
        <label>Verified:</label>
        <input type="checkbox" name="verified" value="1" <?php echo $user['verified']?'checked':''; ?>><br><br>
        <button type="submit">Update User</button>
    </form>
</body>
</html>