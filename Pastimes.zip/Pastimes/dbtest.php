<?php
require_once 'includes/DBConn.php';
echo "Database connection successful!";
?>