<?php
$conn = new mysqli('localhost', 'root', '');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "CREATE DATABASE IF NOT EXISTS ClothingStore";
if ($conn->query($sql)) {
    echo "Database ClothingStore created or already exists.";
} else {
    echo "Error creating database: " . $conn->error;
}
$conn->close();
?>