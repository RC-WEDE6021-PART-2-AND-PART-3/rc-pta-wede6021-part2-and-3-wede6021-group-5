<?php
require_once 'includes/header.php';

$error = '';
$sticky_username = '';
$sticky_email = '';

// If already logged in, redirect to index
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $sticky_username = htmlspecialchars($username);
    $sticky_email = htmlspecialchars($email);

    if (empty($username) || empty($email) || empty($password)) {
        $error = 'All fields are required.';
    } else {
        $stmt = $conn->prepare("SELECT id, full_name, email, username, password_hash, role, verified FROM tblUser WHERE username = ? AND email = ?");
        $stmt->bind_param('ss', $username, $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password_hash'])) {
                if ($user['verified'] == 0 || $user['role'] === 'pending') {
                    $error = 'Your account is pending admin approval.';
                } else {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['full_name'] = $user['full_name'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['role'] = $user['role'];

                    echo "<h2>User " . htmlspecialchars($user['full_name']) . " is logged in</h2>";
                    echo "<table>";
                    echo "<tr><th>Field</th><th>Value</th></tr>";
                    foreach ($user as $column => $value) {
                        if ($column !== 'password_hash') {
                            echo "<tr><td><strong>" . htmlspecialchars($column) . "</strong></td><td>" . htmlspecialchars($value) . "</td></tr>";
                        }
                    }
                    echo "</table>";
                    echo '<br><a href="index.php" class="btn">Go to Home</a>';
                    require_once 'includes/footer.php';
                    exit;
                }
            } else {
                $error = 'Invalid password.';
            }
        } else {
            $error = 'No account found with that username and email.';
        }
        $stmt->close();
    }
}
?>

<h2>Login to Pastimes</h2>

<?php if ($error): ?>
    <div class="alert alert-error"><?php echo $error; ?></div>
<?php endif; ?>

<form method="POST">
    <div class="form-group">
        <label>Username</label>
        <input type="text" name="username" value="<?php echo $sticky_username; ?>" required>
    </div>
    <div class="form-group">
        <label>Email</label>
        <input type="email" name="email" value="<?php echo $sticky_email; ?>" required>
    </div>
    <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" required>
    </div>
    <button type="submit" class="btn">Login</button>
</form>

<p class="mt-20">Don't have an account? <a href="register.php">Register here</a></p>
<p><a href="admin_login.php">Admin Login</a></p>

<?php require_once 'includes/footer.php'; ?>