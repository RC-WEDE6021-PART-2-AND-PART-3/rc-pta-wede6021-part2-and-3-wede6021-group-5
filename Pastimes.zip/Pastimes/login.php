<?php
session_start();
require_once 'includes/DBConn.php';
$error = '';
$sticky_username = '';
$sticky_email = '';

// If already logged in, redirect to dashboard
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Sticky form values
    $sticky_username = htmlspecialchars($username);
    $sticky_email = htmlspecialchars($email);

    // Validation
    if (empty($username) || empty($email) || empty($password)) {
        $error = 'All fields are required.';
    } else {
        // Fetch user
        $stmt = $conn->prepare("SELECT id, full_name, email, username, password_hash, role, verified FROM tblUser WHERE username = ? AND email = ?");
        $stmt->bind_param('ss', $username, $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();

            // Verify password
            if (password_verify($password, $user['password_hash'])) {
                // Check if verified
                if ($user['verified'] == 0 || $user['role'] === 'pending') {
                    $error = 'Your account is pending admin approval. Please wait for verification.';
                } else {
                    // Login successful
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['full_name'] = $user['full_name'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['role'] = $user['role'];

                    echo "<h2>User " . htmlspecialchars($user['full_name']) . " is logged in</h2>";

                    // Display user data using associative read
                    echo "<table border='1' cellpadding='10' style='border-collapse: collapse;'>";
                    echo "<tr><th>Field</th><th>Value</th></tr>";
                    foreach ($user as $column => $value) {
                        if ($column !== 'password_hash') {
                            echo "<tr>";
                            echo "<td><strong>" . htmlspecialchars($column) . "</strong></td>";
                            echo "<td>" . htmlspecialchars($value) . "</td>";
                            echo "</tr>";
                        }
                    }
                    echo "</table>";

                    echo "<br><a href='logout.php'>Logout</a> | <a href='index.php'>Go to Home</a>";
                    exit;
                }
            } else {
                $error = 'Invalid password. Please try again.';
            }
        } else {
            $error = 'No account found with that username and email combination.';
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Pastimes</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h2>Login to Pastimes</h2>

    <?php if ($error): ?>
        <p style="color: red; background: #ffe6e6; padding: 10px; border-radius: 5px;">
            <?php echo $error; ?>
        </p>
    <?php endif; ?>

    <form method="POST" action="">
        <label>Username:</label><br>
        <input type="text" name="username" value="<?php echo $sticky_username; ?>" required><br><br>

        <label>Email:</label><br>
        <input type="email" name="email" value="<?php echo $sticky_email; ?>" required><br><br>

        <label>Password:</label><br>
        <input type="password" name="password" required><br><br>

        <button type="submit">Login</button>
    </form>

    <p>Don't have an account? <a href="register.php">Register here</a></p>
    <p><a href="admin_login.php">Admin Login</a></p>
</body>
</html>