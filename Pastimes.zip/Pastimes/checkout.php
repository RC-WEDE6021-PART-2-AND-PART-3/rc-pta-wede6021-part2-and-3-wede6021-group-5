<?php
session_start();
require_once 'includes/DBConn.php';
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $address = $conn->real_escape_string($_POST['address']);
    $city = $conn->real_escape_string($_POST['city']);
    $code = $conn->real_escape_string($_POST['postal_code']);
    
    // Fetch cart items
    $cart = $conn->query("SELECT c.product_id, c.quantity, p.price FROM tblCart c JOIN tblClothes p ON c.product_id = p.id WHERE c.user_id = {$_SESSION['user_id']}");
    while ($item = $cart->fetch_assoc()) {
        $total = $item['price'] * $item['quantity'];
        $conn->query("INSERT INTO tblOrder (buyer_id, product_id, quantity, total_amount, order_status, delivery_address, city, postal_code)
                      VALUES ({$_SESSION['user_id']}, {$item['product_id']}, {$item['quantity']}, $total, 'pending', '$address', '$city', '$code')");
        // Mark product as sold (optional: set status to 'sold')
        $conn->query("UPDATE tblClothes SET status = 'sold' WHERE id = {$item['product_id']}");
    }
    // Clear cart
    $conn->query("DELETE FROM tblCart WHERE user_id = {$_SESSION['user_id']}");
    echo "<h2>Order placed successfully!</h2><a href='orders.php'>View Orders</a>";
    exit;
}
?>
<!DOCTYPE html>
<html><head><title>Checkout - Pastimes</title></head>
<body>
    <h2>Checkout</h2>
    <form method="POST">
        <textarea name="address" placeholder="Delivery Address" required></textarea><br>
        <input type="text" name="city" placeholder="City" required><br>
        <input type="text" name="postal_code" placeholder="Postal Code" required><br>
        <button type="submit">Place Order</button>
    </form>
</body>
</html>