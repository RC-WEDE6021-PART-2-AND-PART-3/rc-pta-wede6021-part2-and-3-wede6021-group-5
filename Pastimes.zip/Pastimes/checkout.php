<?php
require_once 'includes/header.php';
require_once 'includes/Cart.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$cart = new Cart($_SESSION['user_id']);
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $address = $_POST['address'];
    $city = $_POST['city'];
    $code = $_POST['postal_code'];
    
    $orderNum = $cart->checkout($address, $city, $code);
    if ($orderNum) {
        echo '<h2>Order placed successfully!</h2>';
        echo '<div class="alert alert-success">';
        echo '<p>Your order reference number: <strong>' . $orderNum . '</strong></p>';
        echo '<p>Session ID: ' . session_id() . '</p>';
        echo '</div>';
        echo '<a href="orders.php" class="btn">View Orders</a>';
        require_once 'includes/footer.php';
        exit;
    } else {
        $error = 'Checkout failed. Possibly insufficient stock.';
    }
}
?>

<h2>Checkout</h2>
<?php if ($error): ?>
    <div class="alert alert-error"><?php echo $error; ?></div>
<?php endif; ?>
<form method="POST">
    <div class="form-group">
        <label>Delivery Address</label>
        <textarea name="address" required></textarea>
    </div>
    <div class="form-group">
        <label>City</label>
        <input type="text" name="city" required>
    </div>
    <div class="form-group">
        <label>Postal Code</label>
        <input type="text" name="postal_code" required>
    </div>
    <button type="submit" class="btn">Place Order</button>
</form>

<?php require_once 'includes/footer.php'; ?>