<?php
session_start();
require_once 'includes/DBConn.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'buyer') {
    header('Location: login.php'); exit;
}
$product_id = intval($_POST['product_id']);
$quantity = max(1, intval($_POST['quantity']));

// Check if product already in cart
$check = $conn->query("SELECT id FROM tblCart WHERE user_id = {$_SESSION['user_id']} AND product_id = $product_id");
if ($check->num_rows > 0) {
    $row = $check->fetch_assoc();
    $conn->query("UPDATE tblCart SET quantity = quantity + $quantity WHERE id = {$row['id']}");
} else {
    $conn->query("INSERT INTO tblCart (user_id, product_id, quantity) VALUES ({$_SESSION['user_id']}, $product_id, $quantity)");
}
header('Location: cart.php');
exit;