<?php
session_start();
require_once 'includes/Cart.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'buyer') {
    header('Location: login.php');
    exit;
}
$cart = new Cart($_SESSION['user_id']);
$cart->addItem($_POST['product_id'], $_POST['quantity']);
header('Location: cart.php');
exit;