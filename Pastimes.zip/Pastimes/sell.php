<?php
session_start();
require_once 'includes/DBConn.php';

// Only verified sellers can access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'seller') {
    header('Location: login.php');
    exit;
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $conn->real_escape_string($_POST['title']);
    $desc = $conn->real_escape_string($_POST['description']);
    $price = floatval($_POST['price']);
    $condition = $_POST['condition'];
    $brand = $conn->real_escape_string($_POST['brand']);
    $category = $conn->real_escape_string($_POST['category']);
    $size = $conn->real_escape_string($_POST['size']);
    
    // Handle image upload
    $imgPath = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $targetDir = "uploads/";
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);
        $imgName = time() . "_" . basename($_FILES['image']['name']);
        $targetFile = $targetDir . $imgName;
        if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
            $imgPath = $targetFile;
        }
    }
    
    $sql = "INSERT INTO tblClothes (seller_id, title, description, price, condition_status, brand, category, size, image_path, status)
            VALUES ({$_SESSION['user_id']}, '$title', '$desc', $price, '$condition', '$brand', '$category', '$size', '$imgPath', 'pending')";
    if ($conn->query($sql)) {
        $message = "Item listed successfully! Awaiting admin approval.";
    } else {
        $message = "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Sell Item - Pastimes</title></head>
<body>
    <h2>Sell a Clothing Item</h2>
    <?php if ($message) echo "<p>$message</p>"; ?>
    <form method="POST" enctype="multipart/form-data">
        <input type="text" name="title" placeholder="Title" required><br>
        <textarea name="description" placeholder="Description"></textarea><br>
        <input type="number" step="0.01" name="price" placeholder="Price" required><br>
        <select name="condition" required>
            <option value="">Condition</option>
            <option>Like New</option><option>Very Good</option><option>Good</option><option>Fair</option>
        </select><br>
        <input type="text" name="brand" placeholder="Brand" required><br>
        <input type="text" name="category" placeholder="Category (e.g. Shirt, Jeans)"><br>
        <input type="text" name="size" placeholder="Size (e.g. M, L)"><br>
        <input type="file" name="image" accept="image/*"><br>
        <button type="submit">List Item</button>
    </form>
    <p><a href="index.php">Home</a></p>
</body>
</html>