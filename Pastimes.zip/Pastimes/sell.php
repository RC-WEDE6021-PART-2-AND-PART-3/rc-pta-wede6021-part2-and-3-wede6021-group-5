<?php
require_once 'includes/header.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'seller') {
    header('Location: login.php');
    exit;
}

$message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $conn->real_escape_string($_POST['title']);
    $desc = $conn->real_escape_string($_POST['description']);
    $price = floatval($_POST['price']);
    $condition = $_POST['condition'];
    $brand = $conn->real_escape_string($_POST['brand']);
    $category = $conn->real_escape_string($_POST['category']);
    $size = $conn->real_escape_string($_POST['size']);
    
    $imgPath = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $targetDir = "uploads/";
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);
        $imgName = time() . "_" . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $targetDir . $imgName);
        $imgPath = $targetDir . $imgName;
    }
    
    $sql = "INSERT INTO tblClothes (seller_id, title, description, price, stock_quantity, condition_status, brand, category, size, image_path, status)
            VALUES ({$_SESSION['user_id']}, '$title', '$desc', $price, 1, '$condition', '$brand', '$category', '$size', '$imgPath', 'pending')";
    if ($conn->query($sql)) {
        $message = '<div class="alert alert-success">Item listed successfully! Awaiting admin approval.</div>';
    } else {
        $message = '<div class="alert alert-error">Error: ' . $conn->error . '</div>';
    }
}
?>

<h2>Sell a Clothing Item</h2>
<?php echo $message; ?>
<form method="POST" enctype="multipart/form-data">
    <div class="form-group">
        <label>Title</label>
        <input type="text" name="title" required>
    </div>
    <div class="form-group">
        <label>Description</label>
        <textarea name="description" rows="4"></textarea>
    </div>
    <div class="form-group">
        <label>Price (R)</label>
        <input type="number" step="0.01" name="price" required>
    </div>
    <div class="form-group">
        <label>Condition</label>
        <select name="condition" required>
            <option value="">Select</option>
            <option>Like New</option>
            <option>Very Good</option>
            <option>Good</option>
            <option>Fair</option>
        </select>
    </div>
    <div class="form-group">
        <label>Brand</label>
        <input type="text" name="brand" required>
    </div>
    <div class="form-group">
        <label>Category</label>
        <input type="text" name="category" placeholder="e.g. Jeans, Jacket">
    </div>
    <div class="form-group">
        <label>Size</label>
        <input type="text" name="size" placeholder="e.g. M, L, 32/32">
    </div>
    <div class="form-group">
        <label>Image</label>
        <input type="file" name="image" accept="image/*">
    </div>
    <button type="submit" class="btn">List Item</button>
</form>

<p class="mt-20"><a href="index.php">← Home</a></p>

<?php require_once 'includes/footer.php'; ?>