<?php
require_once 'includes/DBConn.php';
$conn->query("UPDATE tblClothes SET stock_quantity = 5 WHERE stock_quantity IS NULL OR stock_quantity = 0");
echo "Stock updated.";
?>