-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: ClothingStore
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tblcart`
--

DROP TABLE IF EXISTS `tblcart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblcart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT 1,
  `added_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `tblcart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tbluser` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tblcart_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `tblclothes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcart`
--

LOCK TABLES `tblcart` WRITE;
/*!40000 ALTER TABLE `tblcart` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblcart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblclothes`
--

DROP TABLE IF EXISTS `tblclothes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblclothes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `seller_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `condition_status` enum('Like New','Very Good','Good','Fair') NOT NULL,
  `brand` varchar(100) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `size` varchar(20) DEFAULT NULL,
  `image_path` varchar(500) DEFAULT NULL,
  `status` enum('pending','approved','sold') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `seller_id` (`seller_id`),
  CONSTRAINT `tblclothes_ibfk_1` FOREIGN KEY (`seller_id`) REFERENCES `tbluser` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblclothes`
--

LOCK TABLES `tblclothes` WRITE;
/*!40000 ALTER TABLE `tblclothes` DISABLE KEYS */;
INSERT INTO `tblclothes` VALUES (1,6,'Vintage Levi\'s Jeans','Classic 501s, slightly faded',250.00,'Very Good','Levi\'s','Jeans','32/32','uploads/1777822368_placeholder.jpg','sold','2026-05-03 15:32:48'),(2,3,'Item 1','Description for item 1',458.87,'Like New','Reebok','Shorts','M','','approved','2026-05-03 17:43:27'),(3,2,'Item 2','Description for item 2',350.22,'Fair','Reebok','Shoes','S','','approved','2026-05-03 17:43:27'),(4,28,'Item 3','Description for item 3',256.56,'Like New','Puma','Shorts','S','','approved','2026-05-03 17:43:27'),(5,30,'Item 4','Description for item 4',429.99,'Fair','Adidas','Shoes','S','','approved','2026-05-03 17:43:27'),(6,19,'Item 5','Description for item 5',374.41,'Fair','Reebok','Shoes','M','','approved','2026-05-03 17:43:27'),(7,3,'Item 6','Description for item 6',64.12,'Fair','Guess','Dress','L','','approved','2026-05-03 17:43:27'),(8,2,'Item 7','Description for item 7',438.69,'Very Good','Adidas','Jeans','XL','','approved','2026-05-03 17:43:27'),(9,15,'Item 8','Description for item 8',195.22,'Good','Levi\'s','Shorts','S','','approved','2026-05-03 17:43:27'),(10,8,'Item 9','Description for item 9',454.27,'Good','Nike','Dress','S','','approved','2026-05-03 17:43:27'),(11,11,'Item 10','Description for item 10',204.43,'Good','Superbalist','Jacket','S','','approved','2026-05-03 17:43:27'),(12,6,'Item 11','Description for item 11',399.01,'Fair','Guess','Jeans','XL','','approved','2026-05-03 17:43:27'),(13,20,'Item 12','Description for item 12',199.71,'Like New','Levi\'s','Skirt','XL','','approved','2026-05-03 17:43:27'),(14,30,'Item 13','Description for item 13',340.43,'Fair','H&M','Jeans','L','','approved','2026-05-03 17:43:27'),(15,16,'Item 14','Description for item 14',299.25,'Good','Cotton On','Jeans','S','','approved','2026-05-03 17:43:27'),(16,21,'Item 15','Description for item 15',237.29,'Very Good','Nike','T-shirt','XL','','approved','2026-05-03 17:43:27'),(17,7,'Item 16','Description for item 16',333.30,'Like New','Zara','Dress','S','','approved','2026-05-03 17:43:27'),(18,15,'Item 17','Description for item 17',455.82,'Very Good','Reebok','Shoes','S','','approved','2026-05-03 17:43:27'),(19,5,'Item 18','Description for item 18',281.69,'Very Good','Superbalist','Sweater','M','','approved','2026-05-03 17:43:27'),(20,22,'Item 19','Description for item 19',111.62,'Fair','Cotton On','Skirt','S','','approved','2026-05-03 17:43:27'),(21,12,'Item 20','Description for item 20',251.08,'Very Good','Puma','Skirt','S','','approved','2026-05-03 17:43:27'),(22,8,'Item 21','Description for item 21',196.74,'Good','Nike','Jeans','M','','approved','2026-05-03 17:43:27'),(23,22,'Item 22','Description for item 22',242.71,'Fair','Cotton On','Skirt','M','','approved','2026-05-03 17:43:27'),(24,4,'Item 23','Description for item 23',69.07,'Good','Superbalist','Jeans','M','','approved','2026-05-03 17:43:27'),(25,10,'Item 24','Description for item 24',84.04,'Fair','Reebok','Jeans','S','','approved','2026-05-03 17:43:27'),(26,2,'Item 25','Description for item 25',91.05,'Very Good','Nike','Jacket','XL','','approved','2026-05-03 17:43:27'),(27,28,'Item 26','Description for item 26',471.92,'Very Good','Nike','Jacket','M','','approved','2026-05-03 17:43:27'),(28,17,'Item 27','Description for item 27',215.47,'Like New','H&M','Shoes','S','','approved','2026-05-03 17:43:27'),(29,20,'Item 28','Description for item 28',55.77,'Very Good','H&M','Shoes','L','','approved','2026-05-03 17:43:27'),(30,9,'Item 29','Description for item 29',196.01,'Good','H&M','T-shirt','XL','','approved','2026-05-03 17:43:27'),(31,11,'Item 30','Description for item 30',312.59,'Fair','Superbalist','Jacket','L','','approved','2026-05-03 17:43:28');
/*!40000 ALTER TABLE `tblclothes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblorder`
--

DROP TABLE IF EXISTS `tblorder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `buyer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT 1,
  `total_amount` decimal(10,2) NOT NULL,
  `order_status` enum('pending','confirmed','shipped','delivered') DEFAULT 'pending',
  `delivery_address` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `postal_code` varchar(10) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `buyer_id` (`buyer_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `tblorder_ibfk_1` FOREIGN KEY (`buyer_id`) REFERENCES `tbluser` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tblorder_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `tblclothes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblorder`
--

LOCK TABLES `tblorder` WRITE;
/*!40000 ALTER TABLE `tblorder` DISABLE KEYS */;
INSERT INTO `tblorder` VALUES (1,1,1,1,250.00,'pending','123 Main Street, Gardens','Cape Town','8001','2026-05-03 16:07:21'),(2,17,17,2,228.00,'delivered','Address 1, Street 1','Cape Town','8001','2026-05-03 17:43:28'),(3,23,18,3,945.00,'pending','Address 2, Street 2','Cape Town','8001','2026-05-03 17:43:28'),(4,16,9,1,441.00,'pending','Address 3, Street 3','Cape Town','8001','2026-05-03 17:43:28'),(5,28,27,2,360.00,'confirmed','Address 4, Street 4','Cape Town','8001','2026-05-03 17:43:28'),(6,1,11,1,219.00,'delivered','Address 5, Street 5','Cape Town','8001','2026-05-03 17:43:28'),(7,19,7,3,1143.00,'confirmed','Address 6, Street 6','Cape Town','8001','2026-05-03 17:43:28'),(8,21,13,3,1434.00,'confirmed','Address 7, Street 7','Cape Town','8001','2026-05-03 17:43:28'),(9,17,13,3,195.00,'pending','Address 8, Street 8','Cape Town','8001','2026-05-03 17:43:28'),(10,2,7,3,1452.00,'pending','Address 9, Street 9','Cape Town','8001','2026-05-03 17:43:28'),(11,22,22,3,384.00,'confirmed','Address 10, Street 10','Cape Town','8001','2026-05-03 17:43:28'),(12,15,5,3,804.00,'shipped','Address 11, Street 11','Cape Town','8001','2026-05-03 17:43:28'),(13,7,12,3,675.00,'delivered','Address 12, Street 12','Cape Town','8001','2026-05-03 17:43:28'),(14,16,22,2,884.00,'confirmed','Address 13, Street 13','Cape Town','8001','2026-05-03 17:43:28'),(15,13,20,3,996.00,'pending','Address 14, Street 14','Cape Town','8001','2026-05-03 17:43:29'),(16,27,27,3,1056.00,'delivered','Address 15, Street 15','Cape Town','8001','2026-05-03 17:43:29'),(17,13,16,2,724.00,'delivered','Address 16, Street 16','Cape Town','8001','2026-05-03 17:43:29'),(18,4,4,1,396.00,'shipped','Address 17, Street 17','Cape Town','8001','2026-05-03 17:43:29'),(19,18,2,3,1416.00,'delivered','Address 18, Street 18','Cape Town','8001','2026-05-03 17:43:29'),(20,7,23,3,297.00,'confirmed','Address 19, Street 19','Cape Town','8001','2026-05-03 17:43:29'),(21,4,16,1,65.00,'confirmed','Address 20, Street 20','Cape Town','8001','2026-05-03 17:43:29'),(22,15,18,2,840.00,'confirmed','Address 21, Street 21','Cape Town','8001','2026-05-03 17:43:29'),(23,20,4,3,1131.00,'shipped','Address 22, Street 22','Cape Town','8001','2026-05-03 17:43:29'),(24,18,23,2,260.00,'confirmed','Address 23, Street 23','Cape Town','8001','2026-05-03 17:43:29'),(25,16,8,3,657.00,'confirmed','Address 24, Street 24','Cape Town','8001','2026-05-03 17:43:29'),(26,24,28,1,290.00,'confirmed','Address 25, Street 25','Cape Town','8001','2026-05-03 17:43:29'),(27,2,12,2,620.00,'shipped','Address 26, Street 26','Cape Town','8001','2026-05-03 17:43:29'),(28,29,26,1,231.00,'delivered','Address 27, Street 27','Cape Town','8001','2026-05-03 17:43:29'),(29,12,19,1,437.00,'shipped','Address 28, Street 28','Cape Town','8001','2026-05-03 17:43:29'),(30,14,27,1,252.00,'confirmed','Address 29, Street 29','Cape Town','8001','2026-05-03 17:43:29'),(31,15,27,3,390.00,'pending','Address 30, Street 30','Cape Town','8001','2026-05-03 17:43:29');
/*!40000 ALTER TABLE `tblorder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbluser`
--

DROP TABLE IF EXISTS `tbluser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbluser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','seller','buyer','pending') DEFAULT 'pending',
  `verified` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbluser`
--

LOCK TABLES `tbluser` WRITE;
/*!40000 ALTER TABLE `tbluser` DISABLE KEYS */;
INSERT INTO `tbluser` VALUES (1,'John Doe','j.doe@abc.co.za','johndoe','$2y$10$ifPOFMM5Hw/W7zK231H0V.b3zw.g5BBwr6SVic8QhjIrc2W4OsyoC','buyer',1,'2026-05-03 14:46:42'),(2,'Jane Smith','j.smith@abc.co.za','janesmith','$2y$10$ifPOFMM5Hw/W7zK231H0V.b3zw.g5BBwr6SVic8QhjIrc2W4OsyoC','pending',0,'2026-05-03 14:46:42'),(3,'Admin User','admin@pastimes.co.za','admin','$2y$10$ifPOFMM5Hw/W7zK231H0V.b3zw.g5BBwr6SVic8QhjIrc2W4OsyoC','admin',1,'2026-05-03 14:46:42'),(4,'Sarah Connor','s.connor@abc.co.za','sconnor','$2y$10$ifPOFMM5Hw/W7zK231H0V.b3zw.g5BBwr6SVic8QhjIrc2W4OsyoC','pending',0,'2026-05-03 14:46:42'),(5,'Bruce Wayne','b.wayne@abc.co.za','brucew','$2y$10$ifPOFMM5Hw/W7zK231H0V.b3zw.g5BBwr6SVic8QhjIrc2W4OsyoC','pending',0,'2026-05-03 14:46:42'),(6,'Seller One','seller@test.co.za','seller1','$2y$10$pVahQ.qOlRqgeO2BGu4/1OqbMilgM7X/4wr9V7ph3luuyr/lUn9Be','seller',1,'2026-05-03 15:20:59'),(7,'User 6','user6@test.co.za','user6','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','admin',1,'2026-05-03 17:43:27'),(8,'User 7','user7@test.co.za','user7','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','seller',1,'2026-05-03 17:43:27'),(9,'User 8','user8@test.co.za','user8','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','admin',1,'2026-05-03 17:43:27'),(10,'User 9','user9@test.co.za','user9','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','admin',1,'2026-05-03 17:43:27'),(11,'User 10','user10@test.co.za','user10','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','seller',1,'2026-05-03 17:43:27'),(12,'User 11','user11@test.co.za','user11','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','buyer',1,'2026-05-03 17:43:27'),(13,'User 12','user12@test.co.za','user12','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','seller',0,'2026-05-03 17:43:27'),(14,'User 13','user13@test.co.za','user13','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','admin',1,'2026-05-03 17:43:27'),(15,'User 14','user14@test.co.za','user14','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','admin',1,'2026-05-03 17:43:27'),(16,'User 15','user15@test.co.za','user15','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','admin',1,'2026-05-03 17:43:27'),(17,'User 16','user16@test.co.za','user16','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','admin',1,'2026-05-03 17:43:27'),(18,'User 17','user17@test.co.za','user17','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','seller',1,'2026-05-03 17:43:27'),(19,'User 18','user18@test.co.za','user18','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','admin',1,'2026-05-03 17:43:27'),(20,'User 19','user19@test.co.za','user19','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','buyer',0,'2026-05-03 17:43:27'),(21,'User 20','user20@test.co.za','user20','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','seller',1,'2026-05-03 17:43:27'),(22,'User 21','user21@test.co.za','user21','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','seller',0,'2026-05-03 17:43:27'),(23,'User 22','user22@test.co.za','user22','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','admin',1,'2026-05-03 17:43:27'),(24,'User 23','user23@test.co.za','user23','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','admin',1,'2026-05-03 17:43:27'),(25,'User 24','user24@test.co.za','user24','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','seller',1,'2026-05-03 17:43:27'),(26,'User 25','user25@test.co.za','user25','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','seller',0,'2026-05-03 17:43:27'),(27,'User 26','user26@test.co.za','user26','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','admin',1,'2026-05-03 17:43:27'),(28,'User 27','user27@test.co.za','user27','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','buyer',1,'2026-05-03 17:43:27'),(29,'User 28','user28@test.co.za','user28','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','seller',0,'2026-05-03 17:43:27'),(30,'User 29','user29@test.co.za','user29','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','admin',1,'2026-05-03 17:43:27'),(31,'User 30','user30@test.co.za','user30','$2y$10$AvU4oWfSkK1KOIFlCVhGherbEU7Z2D3Mh2U/7HIIVdGlStpQyiv/2','buyer',0,'2026-05-03 17:43:27');
/*!40000 ALTER TABLE `tbluser` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-03 19:46:09
