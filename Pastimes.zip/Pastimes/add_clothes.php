<?php
require_once 'includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: admin_login.php');
    exit;
}

$msg = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $seller_id = intval($_POST['seller_id']);
    $title = $conn->real_escape_string($_POST['title']);
    $desc = $conn->real_escape_string($_POST['description']);
    $price = floatval($_POST['price']);
    $stock = intval($_POST['stock']);
    $condition = $conn->real_escape_string($_POST['condition']);
    $brand = $conn->real_escape_string($_POST['brand']);
    $category = $conn->real_escape_string($_POST['category']);
    $size = $conn->real_escape_string($_POST['size']);

    // Image upload
    $imgPath = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $targetDir = "uploads/";
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);
        $imgName = time() . "_" . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $targetDir . $imgName);
        $imgPath = $targetDir . $imgName;
    }

    $sql = "INSERT INTO tblClothes (seller_id, title, description, price, stock_quantity, condition_status, brand, category, size, image_path, status)
            VALUES ($seller_id, '$title', '$desc', $price, $stock, '$condition', '$brand', '$category', '$size', '$imgPath', 'approved')";

    if ($conn->query($sql)) {
        $msg = '<div class="alert alert-success">Item added and approved.</div>';
    } else {
        $msg = '<div class="alert alert-error">Error: ' . $conn->error . '</div>';
    }
}

$sellers = $conn->query("SELECT id, full_name FROM tblUser WHERE role='seller' AND verified=1");
?>

<h2>Add New Clothing Item (Admin)</h2>
<p><a href="admin_dashboard.php">← Back to Dashboard</a></p>
<?php echo $msg; ?>

<form method="POST" enctype="multipart/form-data">
    <div class="form-group">
        <label>Seller</label>
        <select name="seller_id" required>
            <option value="">Select seller</option>
            <?php while($s = $sellers->fetch_assoc()): ?>
                <option value="<?php echo $s['id']; ?>"><?php echo htmlspecialchars($s['full_name']); ?></option>
            <?php endwhile; ?>
        </select>
    </div>
    <div class="form-group">
        <label>Title</label>
        <input type="text" name="title" required>
    </div>
    <div class="form-group">
        <label>Description</label>
        <textarea name="description" rows="4"></textarea>
    </div>
    <div class="form-group">
        <label>Price (R)</label>
        <input type="number" step="0.01" name="price" required>
    </div>
    <div class="form-group">
        <label>Stock Quantity</label>
        <input type="number" name="stock" value="1" min="1" required>
    </div>
    <div class="form-group">
        <label>Condition</label>
        <select name="condition" required>
            <option value="">Select</option>
            <option>Like New</option>
            <option>Very Good</option>
            <option>Good</option>
            <option>Fair</option>
        </select>
    </div>
    <div class="form-group">
        <label>Brand</label>
        <input type="text" name="brand" required>
    </div>
    <div class="form-group">
        <label>Category</label>
        <input type="text" name="category" placeholder="e.g. Jeans, Jacket">
    </div>
    <div class="form-group">
        <label>Size</label>
        <input type="text" name="size" placeholder="e.g. M, L">
    </div>
    <div class="form-group">
        <label>Image</label>
        <input type="file" name="image" accept="image/*">
    </div>
    <button type="submit" class="btn">Add Item</button>
</form>

<?php require_once 'includes/footer.php'; ?>