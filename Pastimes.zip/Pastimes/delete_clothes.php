<?php
session_start();
require_once 'includes/DBConn.php';
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: admin_login.php');
    exit;
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id > 0) {
    $conn->query("DELETE FROM tblClothes WHERE id = $id");
}
header('Location: admin_dashboard.php');
exit;
?>