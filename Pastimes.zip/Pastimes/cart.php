<?php
session_start();
require_once 'includes/DBConn.php';
if (!isset($_SESSION['user_id'])) { header('Location: login.php'); exit; }

// Handle updates/removals
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update'])) {
        foreach ($_POST['quantity'] as $cartId => $qty) {
            $qty = max(1, intval($qty));
            $conn->query("UPDATE tblCart SET quantity = $qty WHERE id = " . intval($cartId));
        }
    } elseif (isset($_POST['remove'])) {
        $conn->query("DELETE FROM tblCart WHERE id = " . intval($_POST['remove']));
    }
    header('Location: cart.php');
    exit;
}

$items = $conn->query("SELECT c.id as cart_id, p.id as prod_id, p.title, p.price, p.image_path, c.quantity
                       FROM tblCart c JOIN tblClothes p ON c.product_id = p.id
                       WHERE c.user_id = {$_SESSION['user_id']}");
$total = 0;
?>
<!DOCTYPE html>
<html><head><title>Shopping Cart - Pastimes</title></head>
<body>
<h2>Your Cart</h2>
<?php if ($items->num_rows == 0): echo "<p>Cart is empty.</p>"; else: ?>
<form method="POST">
<table border="1" cellpadding="8">
<tr><th>Image</th><th>Title</th><th>Price</th><th>Quantity</th><th>Subtotal</th><th>Action</th></tr>
<?php while($item = $items->fetch_assoc()):
    $sub = $item['price'] * $item['quantity'];
    $total += $sub; ?>
<tr>
    <td><img src="<?php echo $item['image_path'] ?: 'placeholder.jpg'; ?>" width="50"></td>
    <td><?php echo htmlspecialchars($item['title']); ?></td>
    <td>R<?php echo number_format($item['price'],2); ?></td>
    <td><input type="number" name="quantity[<?php echo $item['cart_id']; ?>]" value="<?php echo $item['quantity']; ?>" min="1" style="width:50px"></td>
    <td>R<?php echo number_format($sub,2); ?></td>
    <td>
        <button type="submit" name="update" value="1">Update</button>
        <button type="submit" name="remove" value="<?php echo $item['cart_id']; ?>">Remove</button>
    </td>
</tr>
<?php endwhile; ?>
</table>
</form>
<p>Total: R<?php echo number_format($total,2); ?></p>
<a href="checkout.php">Proceed to Checkout</a>
<?php endif; ?>
<a href="index.php">Continue Shopping</a>
</body>
</html>