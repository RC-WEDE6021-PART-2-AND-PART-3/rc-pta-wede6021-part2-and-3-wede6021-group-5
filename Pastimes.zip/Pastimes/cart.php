<?php
require_once 'includes/header.php';
require_once 'includes/Cart.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$cart = new Cart($_SESSION['user_id']);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update'])) {
        foreach ($_POST['quantity'] as $cartId => $qty) {
            $qty = max(1, intval($qty));
            $cart->updateQuantity($cartId, $qty);
        }
    } elseif (isset($_POST['remove'])) {
        $cart->removeItem($_POST['remove']);
    }
    header('Location: cart.php');
    exit;
}

$items = $cart->getItems();
$total = $cart->getTotal();
?>

<h2>Your Shopping Cart</h2>

<?php if ($items->num_rows == 0): ?>
    <p>Your cart is empty.</p>
<?php else: ?>
    <form method="POST">
        <div style="overflow-x: auto;">
            <table>
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Title</th>
                        <th>Price</th>
                        <th>Stock</th>
                        <th>Quantity</th>
                        <th>Subtotal</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($item = $items->fetch_assoc()):
                        $subtotal = $item['price'] * $item['quantity'];
                    ?>
                        <tr>
                            <td><img src="<?php echo $item['image_path'] ?: 'placeholder.jpg'; ?>" width="60" alt=""></td>
                            <td><?php echo htmlspecialchars($item['title']); ?></td>
                            <td>R <?php echo number_format($item['price'], 2); ?></td>
                            <td><?php echo $item['stock_quantity']; ?></td>
                            <td>
                                <input type="number" name="quantity[<?php echo $item['cart_id']; ?>]" value="<?php echo $item['quantity']; ?>" min="1" max="<?php echo $item['stock_quantity']; ?>" style="width:70px;">
                            </td>
                            <td>R <?php echo number_format($subtotal, 2); ?></td>
                            <td>
                                <button type="submit" name="update" class="btn btn-secondary">Update</button>
                                <button type="submit" name="remove" value="<?php echo $item['cart_id']; ?>" class="btn btn-danger">Remove</button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </form>

    <p class="total">Total: <strong>R <?php echo number_format($total, 2); ?></strong></p>
    <p>
        <a href="checkout.php" class="btn">Proceed to Checkout</a>
    </p>
<?php endif; ?>

<p class="mt-20">
    <a href="index.php">← Continue Shopping</a>
</p>

<?php require_once 'includes/footer.php'; ?>