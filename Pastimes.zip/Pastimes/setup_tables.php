<?php
require_once 'includes/DBConn.php';

// Drop order of FK
$conn->query("DROP TABLE IF EXISTS tblOrder");
$conn->query("DROP TABLE IF EXISTS tblCart");
$conn->query("DROP TABLE IF EXISTS tblClothes");

// tblClothes
$conn->query("CREATE TABLE tblClothes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    seller_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    condition_status ENUM('Like New','Very Good','Good','Fair') NOT NULL,
    brand VARCHAR(100) NOT NULL,
    category VARCHAR(100),
    size VARCHAR(20),
    image_path VARCHAR(500),
    status ENUM('pending','approved','sold') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (seller_id) REFERENCES tblUser(id) ON DELETE CASCADE
)");

// tblCart
$conn->query("CREATE TABLE tblCart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT DEFAULT 1,
    added_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES tblUser(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES tblClothes(id) ON DELETE CASCADE
)");

// tblOrder
$conn->query("CREATE TABLE tblOrder (
    id INT AUTO_INCREMENT PRIMARY KEY,
    buyer_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT DEFAULT 1,
    total_amount DECIMAL(10,2) NOT NULL,
    order_status ENUM('pending','confirmed','shipped','delivered') DEFAULT 'pending',
    delivery_address VARCHAR(255) NOT NULL,
    city VARCHAR(100) NOT NULL,
    postal_code VARCHAR(10) NOT NULL,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (buyer_id) REFERENCES tblUser(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES tblClothes(id) ON DELETE CASCADE
)");

echo "Tables tblClothes, tblCart, tblOrder created.";
?>