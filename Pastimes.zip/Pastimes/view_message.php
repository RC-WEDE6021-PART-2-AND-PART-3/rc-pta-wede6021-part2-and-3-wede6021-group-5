<?php
require_once 'includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$msgId = intval($_GET['id']);
$msg = $conn->query("SELECT m.*, u.full_name AS sender_name FROM tblMessages m JOIN tblUser u ON m.sender_id = u.id WHERE m.id = $msgId")->fetch_assoc();

if (!$msg || ($msg['receiver_id'] != $_SESSION['user_id'] && $msg['sender_id'] != $_SESSION['user_id'])) {
    echo "<p>Access denied.</p>";
    require_once 'includes/footer.php';
    exit;
}

if ($msg['receiver_id'] == $_SESSION['user_id'] && !$msg['is_read']) {
    $conn->query("UPDATE tblMessages SET is_read = 1 WHERE id = $msgId");
}
?>

<h2><?php echo htmlspecialchars($msg['subject']); ?></h2>
<p><strong>From:</strong> <?php echo htmlspecialchars($msg['sender_name']); ?><br>
   <strong>Date:</strong> <?php echo $msg['created_at']; ?></p>
<hr>
<p><?php echo nl2br(htmlspecialchars($msg['message'])); ?></p>

<a href="messages.php" class="btn">← Back to Messages</a>

<?php require_once 'includes/footer.php'; ?>