<?php
require_once 'includes/DBConn.php';
$result = $conn->query("SELECT id, full_name, email, username, role, verified FROM tblUser");
echo "<table border='1' cellpadding='8'>";
echo "<tr><th>ID</th><th>Full Name</th><th>Email</th><th>Username</th><th>Role</th><th>Verified</th></tr>";
while ($row = $result->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . $row['id'] . "</td>";
    echo "<td>" . $row['full_name'] . "</td>";
    echo "<td>" . $row['email'] . "</td>";
    echo "<td>" . $row['username'] . "</td>";
    echo "<td>" . $row['role'] . "</td>";
    echo "<td>" . $row['verified'] . "</td>";
    echo "</tr>";
}
echo "</table>";
?>