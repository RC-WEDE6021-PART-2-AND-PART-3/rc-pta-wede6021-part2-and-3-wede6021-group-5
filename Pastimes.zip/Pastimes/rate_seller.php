<?php
require_once 'includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$order_id = intval($_GET['order_id']);
$seller_id = intval($_GET['seller_id']);

$order = $conn->query("SELECT * FROM tblOrder WHERE id = $order_id AND buyer_id = {$_SESSION['user_id']} AND order_status = 'delivered'")->fetch_assoc();
if (!$order) { echo "<p>Invalid order.</p>"; require_once 'includes/footer.php'; exit; }

$existing = $conn->query("SELECT id FROM tblReviews WHERE order_id = $order_id");
if ($existing->num_rows > 0) { echo "<p>You have already rated this order.</p>"; require_once 'includes/footer.php'; exit; }

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $rating = intval($_POST['rating']);
    $comment = $conn->real_escape_string($_POST['comment']);
    $conn->query("INSERT INTO tblReviews (order_id, buyer_id, seller_id, rating, comment) VALUES ($order_id, {$_SESSION['user_id']}, $seller_id, $rating, '$comment')");
    echo '<div class="alert alert-success">Rating submitted.</div><a href="orders.php" class="btn">Back to orders</a>';
    require_once 'includes/footer.php';
    exit;
}
?>

<h2>Rate the Seller</h2>
<form method="POST">
    <div class="form-group">
        <label>Rating</label>
        <select name="rating" required>
            <option value="">Choose</option>
            <?php for($i=5; $i>=1; $i--) echo "<option value='$i'>$i star" . ($i>1?'s':'') . "</option>"; ?>
        </select>
    </div>
    <div class="form-group">
        <label>Comment (optional)</label>
        <textarea name="comment" rows="4"></textarea>
    </div>
    <button type="submit" class="btn">Submit Rating</button>
</form>

<?php require_once 'includes/footer.php'; ?>