<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once 'DBConn.php';

class Cart {
    private $conn;
    private $userId;

    public function __construct($userId) {
        $this->conn = $GLOBALS['conn'];
        $this->userId = $userId;
    }

    public function addItem($productId, $quantity = 1) {
        // Check if already in cart
        $stmt = $this->conn->prepare("SELECT id FROM tblCart WHERE user_id = ? AND product_id = ?");
        $stmt->bind_param("ii", $this->userId, $productId);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $stmt = $this->conn->prepare("UPDATE tblCart SET quantity = quantity + ? WHERE id = ?");
            $stmt->bind_param("ii", $quantity, $row['id']);
        } else {
            $stmt = $this->conn->prepare("INSERT INTO tblCart (user_id, product_id, quantity) VALUES (?, ?, ?)");
            $stmt->bind_param("iii", $this->userId, $productId, $quantity);
        }
        return $stmt->execute();
    }

    public function removeItem($cartId) {
        $stmt = $this->conn->prepare("DELETE FROM tblCart WHERE id = ? AND user_id = ?");
        $stmt->bind_param("ii", $cartId, $this->userId);
        return $stmt->execute();
    }

    public function updateQuantity($cartId, $quantity) {
        $stmt = $this->conn->prepare("UPDATE tblCart SET quantity = ? WHERE id = ? AND user_id = ?");
        $stmt->bind_param("iii", $quantity, $cartId, $this->userId);
        return $stmt->execute();
    }

    public function getItems() {
        $stmt = $this->conn->prepare("SELECT c.id as cart_id, p.id as prod_id, p.title, p.price, p.image_path, p.stock_quantity, c.quantity
                                      FROM tblCart c JOIN tblClothes p ON c.product_id = p.id
                                      WHERE c.user_id = ?");
        $stmt->bind_param("i", $this->userId);
        $stmt->execute();
        return $stmt->get_result();
    }

    public function getTotal() {
        $items = $this->getItems();
        $total = 0;
        while ($item = $items->fetch_assoc()) {
            $total += $item['price'] * $item['quantity'];
        }
        return $total;
    }

    public function emptyCart() {
        $stmt = $this->conn->prepare("DELETE FROM tblCart WHERE user_id = ?");
        $stmt->bind_param("i", $this->userId);
        return $stmt->execute();
    }

    public function checkout($deliveryAddress, $city, $postalCode) {
        $items = $this->getItems();
        $orderNum = 0;
        $this->conn->begin_transaction();
        try {
            while ($item = $items->fetch_assoc()) {
                if ($item['stock_quantity'] < $item['quantity']) {
                    throw new Exception("Not enough stock for " . $item['title']);
                }
                $total = $item['price'] * $item['quantity'];
                $stmt = $this->conn->prepare("INSERT INTO tblOrder (buyer_id, product_id, quantity, total_amount, order_status, delivery_address, city, postal_code)
                                              VALUES (?, ?, ?, ?, 'pending', ?, ?, ?)");
                $stmt->bind_param("iiidsss", $this->userId, $item['prod_id'], $item['quantity'], $total, $deliveryAddress, $city, $postalCode);
                $stmt->execute();
                if ($orderNum == 0) {
                    $orderNum = $this->conn->insert_id;
                }
                $stmt2 = $this->conn->prepare("UPDATE tblClothes SET stock_quantity = stock_quantity - ? WHERE id = ? AND stock_quantity >= ?");
                $stmt2->bind_param("iii", $item['quantity'], $item['prod_id'], $item['quantity']);
                $stmt2->execute();
                $this->conn->query("UPDATE tblClothes SET status = 'sold' WHERE id = {$item['prod_id']} AND stock_quantity <= 0");
            }
            $this->emptyCart();
            $this->conn->commit();
            return $orderNum;
        } catch (Exception $e) {
            $this->conn->rollback();
            return false;
        }
    }
}
?>