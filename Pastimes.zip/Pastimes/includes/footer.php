    </div> <!-- close container -->
    <footer class="footer">
        <p>&copy; <?php echo date('Y'); ?> Pastimes. All rights reserved. | Second‑Hand Clothing Marketplace</p>
    </footer>
</body>
</html>