<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/DBConn.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pastimes – Second‑Hand Clothing</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav class="navbar">
        <div class="logo">
            <a href="index.php" style="color:white; text-decoration:none;">Past<span>imes</span></a>
        </div>
        <div class="nav-links">
            <?php if (isset($_SESSION['user_id'])): ?>
                <span class="user-info">👤 <?php echo htmlspecialchars($_SESSION['full_name']); ?> (<?php echo $_SESSION['role']; ?>)</span>
                <?php if ($_SESSION['role'] == 'seller'): ?>
                    <a href="sell.php">Sell</a>
                <?php endif; ?>
                <a href="cart.php">🛒 Cart</a>
                <a href="orders.php">Orders</a>
                <a href="messages.php">Messages</a>
                <?php if ($_SESSION['role'] == 'admin'): ?>
                    <a href="admin_dashboard.php">Admin</a>
                <?php endif; ?>
                <a href="logout.php">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a href="register.php">Register</a>
            <?php endif; ?>
        </div>
    </nav>
    <div class="container">