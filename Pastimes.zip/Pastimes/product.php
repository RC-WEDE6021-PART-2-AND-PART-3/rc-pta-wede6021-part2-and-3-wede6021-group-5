<?php
require_once 'includes/header.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$prod = $conn->query("SELECT p.*, u.full_name as seller_name, u.username as seller_username FROM tblClothes p JOIN tblUser u ON p.seller_id = u.id WHERE p.id = $id")->fetch_assoc();
if (!$prod) { echo "<p>Not found.</p>"; require_once 'includes/footer.php'; exit; }
?>

<div style="display:flex; gap:40px; flex-wrap:wrap;">
    <div style="flex:1;">
        <img src="<?php echo $prod['image_path'] ?: 'placeholder.jpg'; ?>" style="width:100%; max-width:400px; border-radius:8px;">
    </div>
    <div style="flex:1;">
        <h1><?php echo htmlspecialchars($prod['title']); ?></h1>
        <p class="price" style="font-size:1.8rem;">R <?php echo number_format($prod['price'], 2); ?></p>
        <p><strong>Brand:</strong> <?php echo htmlspecialchars($prod['brand']); ?></p>
        <p><strong>Condition:</strong> <?php echo $prod['condition_status']; ?></p>
        <p><strong>Size:</strong> <?php echo htmlspecialchars($prod['size']); ?></p>
        <p><strong>Seller:</strong> <?php echo htmlspecialchars($prod['seller_name']); ?> (@<?php echo htmlspecialchars($prod['seller_username']); ?>)</p>
        <p><strong>Description:</strong><br><?php echo nl2br(htmlspecialchars($prod['description'])); ?></p>
        <p><strong>Stock:</strong> <?php echo $prod['stock_quantity']; ?></p>

        <?php if (isset($_SESSION['user_id']) && $_SESSION['role'] == 'buyer'): ?>
            <form method="POST" action="add_to_cart.php" style="margin-top:20px;">
                <input type="hidden" name="product_id" value="<?php echo $prod['id']; ?>">
                <div class="form-group">
                    <label>Quantity:</label>
                    <input type="number" name="quantity" value="1" min="1" max="<?php echo $prod['stock_quantity']; ?>" style="width:80px;">
                </div>
                <button type="submit" class="btn">Add to Cart</button>
            </form>
        <?php elseif (!isset($_SESSION['user_id'])): ?>
            <p><a href="login.php" class="btn">Login as buyer to purchase</a></p>
        <?php endif; ?>
    </div>
</div>

<p class="mt-20"><a href="index.php">← Back to products</a></p>

<?php require_once 'includes/footer.php'; ?>