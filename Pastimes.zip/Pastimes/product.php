<?php
session_start();
require_once 'includes/DBConn.php';
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$prod = $conn->query("SELECT p.*, u.full_name as seller_name, u.username as seller_username FROM tblClothes p JOIN tblUser u ON p.seller_id = u.id WHERE p.id = $id")->fetch_assoc();
if (!$prod) { echo "Not found."; exit; }
?>
<!DOCTYPE html>
<html>
<head><title><?php echo htmlspecialchars($prod['title']); ?> - Pastimes</title></head>
<body>
    <h2><?php echo htmlspecialchars($prod['title']); ?></h2>
    <img src="<?php echo $prod['image_path'] ?: 'placeholder.jpg'; ?>" style="max-width:300px;"><br>
    <p>Brand: <?php echo htmlspecialchars($prod['brand']); ?></p>
    <p>Condition: <?php echo $prod['condition_status']; ?></p>
    <p>Size: <?php echo htmlspecialchars($prod['size']); ?></p>
    <p>Price: R<?php echo number_format($prod['price'], 2); ?></p>
    <p>Seller: <?php echo htmlspecialchars($prod['seller_name']); ?> (@<?php echo htmlspecialchars($prod['seller_username']); ?>)</p>
    <p><?php echo nl2br(htmlspecialchars($prod['description'])); ?></p>
    <?php if (isset($_SESSION['user_id']) && $_SESSION['role'] == 'buyer'): ?>
        <form method="POST" action="add_to_cart.php">
            <input type="hidden" name="product_id" value="<?php echo $prod['id']; ?>">
            Quantity: <input type="number" name="quantity" value="1" min="1" style="width:60px;">
            <button type="submit">Add to Cart</button>
        </form>
    <?php elseif (!isset($_SESSION['user_id'])): ?>
        <p><a href="login.php">Login as buyer to purchase</a></p>
    <?php endif; ?>
    <a href="index.php">Back to products</a>
</body>
</html>