<?php
require_once 'includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

// Handle verify user, delete user, add user (same as before but now with updated form styles)
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['verify_user'])) {
        $userId = intval($_POST['verify_user']);
        $newRole = $_POST['role_assign'] ?? 'buyer';
        $conn->query("UPDATE tblUser SET verified = 1, role = '$newRole' WHERE id = $userId");
    } elseif (isset($_POST['delete_user'])) {
        $userId = intval($_POST['delete_user']);
        $conn->query("DELETE FROM tblUser WHERE id = $userId AND role != 'admin'");
    } elseif (isset($_POST['add_user'])) {
        $name = $conn->real_escape_string($_POST['name']);
        $email = $conn->real_escape_string($_POST['email']);
        $username = $conn->real_escape_string($_POST['username']);
        $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $role = $_POST['role'];
        $conn->query("INSERT INTO tblUser (full_name, email, username, password_hash, role, verified) VALUES ('$name', '$email', '$username', '$pass', '$role', 1)");
    }
    header('Location: admin_dashboard.php');
    exit;
}

$pending = $conn->query("SELECT id, full_name, email, username FROM tblUser WHERE verified = 0");
$allUsers = $conn->query("SELECT id, full_name, email, username, role, verified FROM tblUser ORDER BY created_at DESC");
?>

<h1>Admin Dashboard</h1>

<!-- Pending Users -->
<h2>Pending User Registrations</h2>
<?php if ($pending->num_rows > 0): ?>
    <table>
        <tr><th>ID</th><th>Name</th><th>Email</th><th>Username</th><th>Action</th></tr>
        <?php while ($row = $pending->fetch_assoc()): ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo htmlspecialchars($row['full_name']); ?></td>
            <td><?php echo htmlspecialchars($row['email']); ?></td>
            <td><?php echo htmlspecialchars($row['username']); ?></td>
            <td>
                <form method="POST" style="display:inline;">
                    <input type="hidden" name="verify_user" value="<?php echo $row['id']; ?>">
                    <select name="role_assign">
                        <option value="buyer">Buyer</option>
                        <option value="seller">Seller</option>
                    </select>
                    <button type="submit" class="btn btn-secondary">Verify</button>
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
<?php else: ?>
    <p>No pending registrations.</p>
<?php endif; ?>

<!-- Add New User -->
<h2 class="mt-20">Add New User</h2>
<form method="POST" style="display:flex; gap:10px; flex-wrap:wrap;">
    <input type="text" name="name" placeholder="Full Name" required>
    <input type="email" name="email" placeholder="Email" required>
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <select name="role">
        <option value="buyer">Buyer</option>
        <option value="seller">Seller</option>
    </select>
    <button type="submit" name="add_user" value="1" class="btn">Add User</button>
</form>

<!-- All Users -->
<h2 class="mt-20">All Users</h2>
<table>
    <tr><th>ID</th><th>Name</th><th>Email</th><th>Username</th><th>Role</th><th>Verified</th><th>Actions</th></tr>
    <?php while ($user = $allUsers->fetch_assoc()): ?>
    <tr>
        <td><?php echo $user['id']; ?></td>
        <td><?php echo htmlspecialchars($user['full_name']); ?></td>
        <td><?php echo htmlspecialchars($user['email']); ?></td>
        <td><?php echo htmlspecialchars($user['username']); ?></td>
        <td><?php echo $user['role']; ?></td>
        <td><?php echo $user['verified'] ? 'Yes' : 'No'; ?></td>
        <td>
            <a href="edit_user.php?id=<?php echo $user['id']; ?>" class="btn btn-secondary">Edit</a>
            <form method="POST" style="display:inline;" onsubmit="return confirm('Delete?');">
                <input type="hidden" name="delete_user" value="<?php echo $user['id']; ?>">
                <button type="submit" class="btn btn-danger">Delete</button>
            </form>
        </td>
    </tr>
    <?php endwhile; ?>
</table>

<!-- Pending Product Listings -->
<h2 class="mt-20">Pending Product Listings</h2>
<?php
$pendingProducts = $conn->query("SELECT p.id, p.title, p.price, u.full_name as seller FROM tblClothes p JOIN tblUser u ON p.seller_id = u.id WHERE p.status = 'pending'");
if ($pendingProducts->num_rows > 0): ?>
    <table>
        <tr><th>ID</th><th>Title</th><th>Price</th><th>Seller</th><th>Action</th></tr>
        <?php while($prod = $pendingProducts->fetch_assoc()): ?>
        <tr>
            <td><?php echo $prod['id']; ?></td>
            <td><?php echo htmlspecialchars($prod['title']); ?></td>
            <td>R<?php echo number_format($prod['price'], 2); ?></td>
            <td><?php echo htmlspecialchars($prod['seller']); ?></td>
            <td>
                <a href="approve_product.php?id=<?php echo $prod['id']; ?>&action=approve" class="btn btn-secondary">Approve</a>
                <a href="approve_product.php?id=<?php echo $prod['id']; ?>&action=reject" class="btn btn-danger">Reject</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
<?php else: echo "<p>No pending products.</p>"; endif; ?>

<!-- Clothing Management -->
<h2 class="mt-20">Clothing Management</h2>
<a href="add_clothes.php" class="btn">Add New Item</a>
<div style="overflow-x: auto; margin-top: 10px;">
    <table>
        <tr><th>ID</th><th>Image</th><th>Title</th><th>Price</th><th>Stock</th><th>Status</th><th>Actions</th></tr>
        <?php
        $allClothes = $conn->query("SELECT * FROM tblClothes");
        while($cloth = $allClothes->fetch_assoc()):
        ?>
        <tr>
            <td><?php echo $cloth['id']; ?></td>
            <td><img src="<?php echo $cloth['image_path'] ?: 'placeholder.jpg'; ?>" width="50"></td>
            <td><?php echo htmlspecialchars($cloth['title']); ?></td>
            <td>R<?php echo number_format($cloth['price'],2); ?></td>
            <td><?php echo $cloth['stock_quantity']; ?></td>
            <td><?php echo $cloth['status']; ?></td>
            <td>
                <a href="edit_clothes.php?id=<?php echo $cloth['id']; ?>" class="btn btn-secondary">Edit</a>
                <a href="delete_clothes.php?id=<?php echo $cloth['id']; ?>" class="btn btn-danger" onclick="return confirm('Delete?')">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<?php require_once 'includes/footer.php'; ?>