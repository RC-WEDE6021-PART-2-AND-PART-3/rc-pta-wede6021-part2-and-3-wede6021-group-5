<?php
require_once 'includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = $_SESSION['user_id'];

$received = $conn->query("SELECT m.*, u.full_name AS sender_name, u.username AS sender_username
                         FROM tblMessages m JOIN tblUser u ON m.sender_id = u.id
                         WHERE m.receiver_id = $userId ORDER BY m.created_at DESC");

$sent = $conn->query("SELECT m.*, u.full_name AS receiver_name, u.username AS receiver_username
                     FROM tblMessages m JOIN tblUser u ON m.receiver_id = u.id
                     WHERE m.sender_id = $userId ORDER BY m.created_at DESC");
?>

<h2>My Messages</h2>
<p><a href="compose_message.php" class="btn">Compose New Message</a></p>

<h3 class="mt-20">Received</h3>
<?php if ($received->num_rows == 0): ?>
    <p>No messages.</p>
<?php else: ?>
    <table>
        <tr><th>From</th><th>Subject</th><th>Date</th><th>Status</th></tr>
        <?php while($msg = $received->fetch_assoc()): ?>
        <tr>
            <td><?php echo htmlspecialchars($msg['sender_name']); ?></td>
            <td><a href="view_message.php?id=<?php echo $msg['id']; ?>"><?php echo htmlspecialchars($msg['subject']); ?></a></td>
            <td><?php echo $msg['created_at']; ?></td>
            <td><?php echo $msg['is_read'] ? 'Read' : '<strong style="color:#2c7a7b;">New</strong>'; ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
<?php endif; ?>

<h3 class="mt-20">Sent</h3>
<?php if ($sent->num_rows == 0): ?>
    <p>No sent messages.</p>
<?php else: ?>
    <table>
        <tr><th>To</th><th>Subject</th><th>Date</th></tr>
        <?php while($msg = $sent->fetch_assoc()): ?>
        <tr>
            <td><?php echo htmlspecialchars($msg['receiver_name']); ?></td>
            <td><?php echo htmlspecialchars($msg['subject']); ?></td>
            <td><?php echo $msg['created_at']; ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>