<?php
require_once 'includes/DBConn.php';

// Read the SQL file
$sql = file_get_contents('myClothingStore.sql');
if ($sql === false) {
    die("Could not read myClothingStore.sql");
}

// Execute multi query
if ($conn->multi_query($sql)) {
    // Flush multi results
    do {
        if ($result = $conn->store_result()) {
            $result->free();
        }
    } while ($conn->more_results() && $conn->next_result());
    echo "Database and tables recreated successfully from myClothingStore.sql.";
} else {
    echo "Error: " . $conn->error;
}
?>