<?php
session_start();
require_once 'includes/DBConn.php';

// Fetch approved items
$sql = "SELECT * FROM tblClothes WHERE status = 'approved'";
$filters = [];
if (isset($_GET['brand']) && $_GET['brand'] != '') {
    $brand = $conn->real_escape_string($_GET['brand']);
    $filters[] = "brand LIKE '%$brand%'";
}
if (isset($_GET['condition']) && $_GET['condition'] != '') {
    $cond = $conn->real_escape_string($_GET['condition']);
    $filters[] = "condition_status = '$cond'";
}
if (isset($_GET['min_price']) && is_numeric($_GET['min_price'])) {
    $filters[] = "price >= {$_GET['min_price']}";
}
if (isset($_GET['max_price']) && is_numeric($_GET['max_price'])) {
    $filters[] = "price <= {$_GET['max_price']}";
}
if (count($filters)) $sql .= " AND " . implode(" AND ", $filters);
$sql .= " ORDER BY created_at DESC";

$items = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head><title>Pastimes - Second-Hand Clothing</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Pastimes</h1>
    <p>
        <?php if (isset($_SESSION['user_id'])): ?>
            Hello, <?php echo $_SESSION['full_name']; ?> |
            <?php if ($_SESSION['role'] == 'seller'): ?><a href="sell.php">Sell Item</a> |<?php endif; ?>
            <a href="cart.php">Cart</a> | <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a> | <a href="register.php">Register</a>
        <?php endif; ?>
    </p>

    <!-- Filters -->
    <form method="GET">
        Brand: <input type="text" name="brand" value="<?php echo $_GET['brand']??''; ?>">
        Condition: <select name="condition">
            <option value="">All</option>
            <option>Like New</option><option>Very Good</option><option>Good</option><option>Fair</option>
        </select>
        Min Price: <input type="number" step="0.01" name="min_price" style="width:80px">
        Max Price: <input type="number" step="0.01" name="max_price" style="width:80px">
        <button type="submit">Filter</button>
    </form>

    <!-- Products Grid -->
    <div style="display:flex; flex-wrap:wrap; gap:20px; margin-top:20px;">
        <?php while($item = $items->fetch_assoc()): ?>
        <div style="border:1px solid #ccc; padding:10px; width:200px;">
            <img src="<?php echo $item['image_path'] ?: 'placeholder.jpg'; ?>" style="width:100%; height:150px; object-fit:cover;"><br>
            <strong><?php echo htmlspecialchars($item['title']); ?></strong><br>
            <?php echo htmlspecialchars($item['brand']); ?> - <?php echo $item['condition_status']; ?><br>
            R<?php echo number_format($item['price'], 2); ?><br>
            <a href="product.php?id=<?php echo $item['id']; ?>">View Details</a>
        </div>
        <?php endwhile; ?>
    </div>
</body>
</html>