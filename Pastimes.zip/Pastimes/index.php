<?php
require_once 'includes/header.php';

// Fetch approved products (DBConn already included via header)
$sql = "SELECT * FROM tblClothes WHERE status = 'approved' AND stock_quantity > 0";
$filters = [];
if (!empty($_GET['brand'])) {
    $brand = $conn->real_escape_string($_GET['brand']);
    $filters[] = "brand LIKE '%$brand%'";
}
if (!empty($_GET['condition'])) {
    $cond = $conn->real_escape_string($_GET['condition']);
    $filters[] = "condition_status = '$cond'";
}
if (!empty($_GET['min_price']) && is_numeric($_GET['min_price'])) {
    $filters[] = "price >= {$_GET['min_price']}";
}
if (!empty($_GET['max_price']) && is_numeric($_GET['max_price'])) {
    $filters[] = "price <= {$_GET['max_price']}";
}
if (count($filters)) {
    $sql .= " AND " . implode(" AND ", $filters);
}
$sql .= " ORDER BY created_at DESC";
$items = $conn->query($sql);
?>

<h1>Welcome to Pastimes</h1>
<p style="font-size:1.2rem; color:#475569; margin-bottom:30px;">
    Your curated marketplace for pre‑loved branded clothing. Quality, sustainability, and style – all in one place.
</p>

<!-- Filter form -->
<form method="GET" style="display:flex; gap:15px; flex-wrap:wrap; margin-bottom:30px;">
    <div class="form-group" style="flex:1;">
        <input type="text" name="brand" placeholder="Brand" value="<?php echo $_GET['brand']??''; ?>">
    </div>
    <div class="form-group" style="flex:1;">
        <select name="condition">
            <option value="">All Conditions</option>
            <option <?php if(isset($_GET['condition'])&&$_GET['condition']=='Like New')echo'selected';?>>Like New</option>
            <option <?php if(isset($_GET['condition'])&&$_GET['condition']=='Very Good')echo'selected';?>>Very Good</option>
            <option <?php if(isset($_GET['condition'])&&$_GET['condition']=='Good')echo'selected';?>>Good</option>
            <option <?php if(isset($_GET['condition'])&&$_GET['condition']=='Fair')echo'selected';?>>Fair</option>
        </select>
    </div>
    <div class="form-group" style="flex:1;">
        <input type="number" step="0.01" name="min_price" placeholder="Min Price" value="<?php echo $_GET['min_price']??''; ?>">
    </div>
    <div class="form-group" style="flex:1;">
        <input type="number" step="0.01" name="max_price" placeholder="Max Price" value="<?php echo $_GET['max_price']??''; ?>">
    </div>
    <button type="submit" class="btn" style="align-self:flex-end;">Filter</button>
</form>

<!-- Product Grid -->
<div class="card-grid">
    <?php while($item = $items->fetch_assoc()): ?>
    <div class="card">
        <img src="<?php echo $item['image_path'] ?: 'placeholder.jpg'; ?>" alt="<?php echo htmlspecialchars($item['title']); ?>">
        <div class="card-body">
            <h3><?php echo htmlspecialchars($item['title']); ?></h3>
            <p class="meta"><?php echo htmlspecialchars($item['brand']); ?> · <?php echo $item['condition_status']; ?></p>
            <p class="price">R <?php echo number_format($item['price'],2); ?></p>
            <p class="meta">Stock: <?php echo $item['stock_quantity']; ?></p>
            <a href="product.php?id=<?php echo $item['id']; ?>" class="btn">View Details</a>
        </div>
    </div>
    <?php endwhile; ?>
</div>

<?php require_once 'includes/footer.php'; ?>