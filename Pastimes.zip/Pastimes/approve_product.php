<?php
session_start();
require_once 'includes/DBConn.php';
if ($_SESSION['role'] != 'admin') { header('Location: admin_login.php'); exit; }

$id = intval($_GET['id']);
$action = $_GET['action'];
if ($action == 'approve') {
    $conn->query("UPDATE tblClothes SET status = 'approved' WHERE id = $id");
} else if ($action == 'reject') {
    // Delete or just mark as rejected? We'll delete for simplicity.
    $conn->query("DELETE FROM tblClothes WHERE id = $id");
}
header('Location: admin_dashboard.php');
exit;
?>