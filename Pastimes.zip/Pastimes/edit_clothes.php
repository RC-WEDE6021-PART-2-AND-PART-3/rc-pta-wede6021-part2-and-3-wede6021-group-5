<?php
require_once 'includes/header.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    header('Location: admin_login.php');
    exit;
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$clothes = $conn->query("SELECT * FROM tblClothes WHERE id = $id")->fetch_assoc();
if (!$clothes) {
    echo "<p>Item not found.</p>";
    require_once 'includes/footer.php';
    exit;
}

$msg = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $seller_id = intval($_POST['seller_id']);
    $title = $conn->real_escape_string($_POST['title']);
    $desc = $conn->real_escape_string($_POST['description']);
    $price = floatval($_POST['price']);
    $stock = intval($_POST['stock']);
    $condition = $conn->real_escape_string($_POST['condition']);
    $brand = $conn->real_escape_string($_POST['brand']);
    $category = $conn->real_escape_string($_POST['category']);
    $size = $conn->real_escape_string($_POST['size']);

    $imgPath = $clothes['image_path'];
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $targetDir = "uploads/";
        $imgName = time() . "_" . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $targetDir . $imgName);
        $imgPath = $targetDir . $imgName;
    }

    $sql = "UPDATE tblClothes SET
                seller_id = $seller_id,
                title = '$title',
                description = '$desc',
                price = $price,
                stock_quantity = $stock,
                condition_status = '$condition',
                brand = '$brand',
                category = '$category',
                size = '$size',
                image_path = '$imgPath'
            WHERE id = $id";

    if ($conn->query($sql)) {
        $msg = '<div class="alert alert-success">Item updated.</div>';
        $clothes = $conn->query("SELECT * FROM tblClothes WHERE id = $id")->fetch_assoc();
    } else {
        $msg = '<div class="alert alert-error">Error: ' . $conn->error . '</div>';
    }
}

$sellers = $conn->query("SELECT id, full_name FROM tblUser WHERE role='seller' AND verified=1");
?>

<h2>Edit Clothing Item</h2>
<p><a href="admin_dashboard.php">← Back to Dashboard</a></p>
<?php echo $msg; ?>

<form method="POST" enctype="multipart/form-data">
    <div class="form-group">
        <label>Seller</label>
        <select name="seller_id" required>
            <?php while($s = $sellers->fetch_assoc()): ?>
                <option value="<?php echo $s['id']; ?>" <?php if($s['id']==$clothes['seller_id']) echo 'selected'; ?>>
                    <?php echo htmlspecialchars($s['full_name']); ?>
                </option>
            <?php endwhile; ?>
        </select>
    </div>
    <div class="form-group">
        <label>Title</label>
        <input type="text" name="title" value="<?php echo htmlspecialchars($clothes['title']); ?>" required>
    </div>
    <div class="form-group">
        <label>Description</label>
        <textarea name="description" rows="4"><?php echo htmlspecialchars($clothes['description']); ?></textarea>
    </div>
    <div class="form-group">
        <label>Price (R)</label>
        <input type="number" step="0.01" name="price" value="<?php echo $clothes['price']; ?>" required>
    </div>
    <div class="form-group">
        <label>Stock Quantity</label>
        <input type="number" name="stock" value="<?php echo $clothes['stock_quantity']; ?>" min="1" required>
    </div>
    <div class="form-group">
        <label>Condition</label>
        <select name="condition" required>
            <?php $conds = ['Like New','Very Good','Good','Fair'];
            foreach($conds as $c): ?>
                <option <?php if($clothes['condition_status']==$c) echo 'selected'; ?>><?php echo $c; ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="form-group">
        <label>Brand</label>
        <input type="text" name="brand" value="<?php echo htmlspecialchars($clothes['brand']); ?>" required>
    </div>
    <div class="form-group">
        <label>Category</label>
        <input type="text" name="category" value="<?php echo htmlspecialchars($clothes['category']); ?>">
    </div>
    <div class="form-group">
        <label>Size</label>
        <input type="text" name="size" value="<?php echo htmlspecialchars($clothes['size']); ?>">
    </div>
    <div class="form-group">
        <label>Current Image</label><br>
        <img src="<?php echo $clothes['image_path'] ?: 'placeholder.jpg'; ?>" width="100"><br>
        <label>Replace Image (optional)</label>
        <input type="file" name="image" accept="image/*">
    </div>
    <button type="submit" class="btn">Update Item</button>
</form>

<?php require_once 'includes/footer.php'; ?>