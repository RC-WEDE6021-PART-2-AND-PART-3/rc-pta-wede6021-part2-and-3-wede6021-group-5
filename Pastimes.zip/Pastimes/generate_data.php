<?php
// Simple generator for 30 rows each table
// Users
$users = [];
$hash = password_hash('password123', PASSWORD_DEFAULT);
$roles = ['buyer','seller','admin'];
$verified = [0,1];
for ($i=6; $i<=30; $i++) {
    $name = "User $i";
    $email = "user$i@test.co.za";
    $username = "user$i";
    $role = $roles[array_rand($roles)];
    $ver = ($role == 'admin' || rand(0,1)) ? 1 : 0;
    $users[] = "$name,$email,$username,$hash,$role,$ver";
}
file_put_contents('data/userData30.txt', implode("\n", $users));

// Clothes
$clothes = [];
$brands = ['Levi\'s','Nike','Adidas','Zara','H&M','Guess','Cotton On','Superbalist','Puma','Reebok'];
$conds = ['Like New','Very Good','Good','Fair'];
$cats = ['Jeans','T-shirt','Jacket','Dress','Shoes','Sweater','Skirt','Shorts'];
for ($i=1; $i<=30; $i++) {
    $title = "Item $i";
    $desc = "Description for item $i";
    $price = rand(50, 500) + rand(0,99)/100;
    $brand = $brands[array_rand($brands)];
    $cond = $conds[array_rand($conds)];
    $cat = $cats[array_rand($cats)];
    $size = ['S','M','L','XL'][array_rand(['S','M','L','XL'])];
    $seller_id = rand(2,30); // sellers
    $status = 'approved';
    $img = '';
    $clothes[] = "$seller_id,\"$title\",\"$desc\",$price,$cond,\"$brand\",\"$cat\",\"$size\",\"$img\",$status";
}
file_put_contents('data/clothesData.txt', implode("\n", $clothes));

// Orders
$orders = [];
for ($i=1; $i<=30; $i++) {
    $buyer_id = rand(1,30);
    $clothes_id = rand(1,30); // assuming clothes ids exist
    $qty = rand(1,3);
    $price = rand(50,500);
    $total = $price * $qty;
    $status = ['pending','confirmed','shipped','delivered'][array_rand([0,1,2,3])];
    $address = "Address $i, Street $i";
    $city = 'Cape Town';
    $code = '8001';
    $orders[] = "$buyer_id,$clothes_id,$qty,$total,\"$status\",\"$address\",\"$city\",\"$code\"";
}
file_put_contents('data/ordersData.txt', implode("\n", $orders));
echo "Text files generated in data/ folder.";
?>